# **App Name**: FX AI Pro

## Core Features:

- AI-Powered Trading Strategy Tool: An intelligent tool that analyzes historical and real-time market data to suggest optimized trading parameters and identify high-probability trade setups for automated execution.
- Forex Broker API Integration: Securely connect and integrate with major forex broker APIs to fetch real-time market data and execute trades automatically on behalf of the user's linked trading account.
- Strategy Parameter Management UI: A web-based interface allowing users to define, adjust, and activate their preferred trading strategies, risk tolerance, and asset selection for automated operations.
- Telegram Live Alerts: Real-time push notifications delivered to the user's Telegram chat for crucial events, including trade entries, exits, profit/loss updates, and critical system status changes.
- Live Trading Dashboard: A dynamic dashboard providing a real-time overview of the bot's current trading activity, including open positions, current profit/loss, account equity, and margin levels.
- Historical Performance Log: A comprehensive log of all executed trades, detailing entry/exit points, trade duration, and individual profit/loss, along with basic cumulative performance metrics.

## Style Guidelines:

- Primary brand color: #6699FF (RGB: 102, 153, 255). A modern, professional blue evoking trust and reliability, used for interactive elements and key information.
- Background color: #20232B (RGB: 32, 35, 43). A deep, desaturated charcoal grey-blue providing a sophisticated and focused dark theme ideal for financial data monitoring.
- Accent color: #4DD9F0 (RGB: 77, 217, 240). A vibrant cyan, chosen to provide distinct contrast and highlight calls to action, important alerts, and positive indicators in the dark theme.
- The primary font for both headlines and body text will be 'Inter', a grotesque-style sans-serif, chosen for its modern, objective, and highly legible appearance suitable for displaying data-dense financial information.
- Utilize a consistent set of minimalist, line-based icons. Focus on easily recognizable financial symbols (e.g., charts, arrows, candlestick patterns) and clear status indicators to enhance data interpretation.
- Design clean, efficient layouts with a clear hierarchy for dashboards and configuration screens. Prioritize information density for financial metrics while ensuring readability and mobile responsiveness.
- Implement subtle and purposeful animations for real-time data updates, loading states, and state changes within the UI. Animations should be non-distracting and enhance the user experience by indicating system responsiveness.