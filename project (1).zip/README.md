
# 🌐 NEXUS PRO - MANUAL HOSTING & MOBILE GUIDE

### 🚀 HOW TO DEPLOY TO WEB (MANUALLY)
1. **Stop Server:** Press **Ctrl + C**.
2. **Run Build:** Type `npm run build` and press Enter.
3. **Find the folder:** A folder named **`out`** has been created in your project directory.
4. **Upload:** Upload all contents of the `out` folder directly into your server's directory (e.g., `/Nexuspro`).

---

### 📱 HOW TO USE WITH ANDROID STUDIO
1. **Install Mobile Wrapper:** Run `npm run build`.
2. **Add Android Platform:** Run `npx cap add android`.
3. **Open Android Studio:** Select the **`android`** folder from this project.
4. **Build APK:** In Android Studio, go to `Build > Build Bundle(s) / APK(s) > Build APK(s)`.

---

### 🔑 PLATFORM DEFAULTS (Hardcoded)
- **Bank:** Firstbank Nigeria
- **Account:** 3082143955
- **USDT Address (TRC20):** TRS3HuiKEW1BLZPhGJAAzxSGgf9XrcraZJ
- **WhatsApp Support:** +2347031335805
- **Telegram Bot:** @Fxaipro_bot
- **Admin Master Key:** `NexusPro#2025`

**Admin Portal:** `/admin/` (Use the Master Key above to unlock)
