
import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.nexus.pro',
  appName: 'Nexus Pro',
  webDir: 'out',
  server: {
    androidScheme: 'https'
  }
};

export default config;
