"use client"

import * as React from "react"
import { 
  Save, 
  RefreshCw, 
  AlertTriangle,
  Landmark as BrokerIcon,
  Smartphone,
  SmartphoneNfc,
  Lock,
  User,
  Activity,
  FlaskConical,
  Zap
} from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useFirestore, useUser, useDoc } from "@/firebase"
import { doc, setDoc, serverTimestamp } from "firebase/firestore"
import { errorEmitter } from "@/firebase/error-emitter"
import { FirestorePermissionError } from "@/firebase/errors"

export default function SettingsPage() {
  const { toast } = useToast()
  const db = useFirestore()
  const { user } = useUser()
  const [isSaving, setIsSaving] = React.useState(false)

  const brokerRef = React.useMemo(() => {
    if (!db || !user) return null
    return doc(db, 'users', user.uid, 'config', 'broker')
  }, [db, user])

  const { data: brokerData, loading: loadingConfig } = useDoc(brokerRef)

  const [formData, setFormData] = React.useState({
    platform: "meta-trader-5",
    accountType: "demo",
    server: "",
    login: "",
    password: "",
    apiKey: "",
    tokenName: "",
    secretToken: "",
    token: ""
  })

  React.useEffect(() => {
    if (brokerData) {
      setFormData({
        platform: brokerData.platform || "meta-trader-5",
        accountType: brokerData.accountType || "demo",
        server: brokerData.server || "",
        login: brokerData.login || "",
        password: brokerData.password || "",
        apiKey: brokerData.apiKey || "",
        tokenName: brokerData.tokenName || "",
        secretToken: brokerData.secretToken || "",
        token: brokerData.token || ""
      })
    }
  }, [brokerData])

  const handleSave = () => {
    if (!db || !user || !brokerRef) return

    setIsSaving(true)
    
    setDoc(brokerRef, {
      ...formData,
      updatedAt: serverTimestamp()
    }, { merge: true })
      .then(() => {
        setIsSaving(false)
        toast({
          title: "Nexus Link Active",
          description: `Your ${formData.accountType.toUpperCase()} broker credentials synchronized.`
        })
      })
      .catch(async () => {
        setIsSaving(false)
        const permissionError = new FirestorePermissionError({
          path: brokerRef.path,
          operation: 'write',
          requestResourceData: formData
        })
        errorEmitter.emit('permission-error', permissionError)
      })
  }

  const showServerField = ["meta-trader-5", "meta-trader-4", "exness", "deriv-forex"].includes(formData.platform)
  const showLoginFields = ["meta-trader-5", "meta-trader-4", "exness", "pocket-broker", "quotex", "iq-option", "deriv-forex"].includes(formData.platform)
  const showApiFields = ["deriv-binary", "binance", "bybit"].includes(formData.platform)
  const showTokenNameField = formData.platform === "deriv-binary"
  const showTokenField = ["pocket-broker", "quotex"].includes(formData.platform)

  return (
    <div className="max-w-5xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700 pb-10">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-headline font-bold tracking-tight text-foreground">Nexus Broker Terminal</h1>
          <p className="text-muted-foreground mt-1 text-lg font-medium">Configure autonomous execution protocols for Demo and Real accounts.</p>
        </div>
        <div className="flex items-center gap-3 bg-accent/5 border border-accent/20 px-4 py-2 rounded-2xl">
          <div className="h-2 w-2 rounded-full bg-accent animate-pulse" />
          <span className="text-[10px] font-bold text-accent uppercase tracking-[0.2em]">Secure Cloud Node v1.0.0</span>
        </div>
      </div>

      <Tabs defaultValue="config" className="w-full">
        <TabsList className="grid w-full md:w-[600px] grid-cols-3 bg-white/5 p-1 mb-8">
          <TabsTrigger value="config" className="font-bold uppercase text-[10px] tracking-widest">Configuration</TabsTrigger>
          <TabsTrigger value="mobile" className="font-bold uppercase text-[10px] tracking-widest">Mobile Install</TabsTrigger>
          <TabsTrigger value="guide" className="font-bold uppercase text-[10px] tracking-widest">Setup Guide</TabsTrigger>
        </TabsList>

        <TabsContent value="config" className="space-y-8 animate-in fade-in duration-500">
          <Card className="border-white/5 bg-card/60 shadow-2xl overflow-hidden">
            <div className="bg-primary/5 p-8 border-b border-white/5 flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-2xl bg-primary/10 text-primary shadow-lg">
                  <BrokerIcon size={28} />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-foreground">Broker Handshake</h3>
                  <p className="text-sm text-muted-foreground font-medium">Link your account for 24/7 autonomous execution.</p>
                </div>
              </div>
              <Badge variant="outline" className={`font-bold px-4 py-1 tracking-widest uppercase text-[10px] ${brokerData ? 'text-accent border-accent/40 bg-accent/5' : 'text-muted-foreground'}`}>
                {brokerData ? 'NEXUS LINKED' : 'STANDBY'}
              </Badge>
            </div>
            <CardContent className="p-8 space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-3">
                  <Label className="text-[10px] font-bold uppercase text-muted-foreground tracking-widest">Select Broker Platform</Label>
                  <Select 
                    value={formData.platform} 
                    onValueChange={(v) => setFormData(prev => ({ ...prev, platform: v }))}
                  >
                    <SelectTrigger className="bg-background/50 border-white/10 h-12 rounded-xl text-foreground font-medium">
                      <SelectValue placeholder="Select broker" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="meta-trader-5">MetaTrader 5 (MT5)</SelectItem>
                      <SelectItem value="meta-trader-4">MetaTrader 4 (MT4)</SelectItem>
                      <SelectItem value="deriv-binary">Deriv Binary (API Key)</SelectItem>
                      <SelectItem value="deriv-forex">Deriv Forex (MT5)</SelectItem>
                      <SelectItem value="pocket-broker">Pocket Option / Broker</SelectItem>
                      <SelectItem value="quotex">Quotex Terminal</SelectItem>
                      <SelectItem value="iq-option">IQ Option</SelectItem>
                      <SelectItem value="exness">Exness Global</SelectItem>
                      <SelectItem value="binance">Binance (Crypto)</SelectItem>
                      <SelectItem value="bybit">Bybit (Crypto)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-3">
                  <Label className="text-[10px] font-bold uppercase text-muted-foreground tracking-widest">Account Execution Mode</Label>
                  <Select 
                    value={formData.accountType} 
                    onValueChange={(v) => setFormData(prev => ({ ...prev, accountType: v }))}
                  >
                    <SelectTrigger className="bg-background/50 border-white/10 h-12 rounded-xl text-foreground font-medium">
                      <SelectValue placeholder="Select mode" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="demo">
                        <div className="flex items-center gap-2">
                          <FlaskConical size={14} className="text-accent" />
                          <span>Demo / Practice Account</span>
                        </div>
                      </SelectItem>
                      <SelectItem value="real">
                        <div className="flex items-center gap-2">
                          <Zap size={14} className="text-primary" />
                          <span>Real / Live Funds</span>
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {showServerField && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-3">
                    <Label className="text-[10px] font-bold uppercase text-muted-foreground tracking-widest">Broker Server Name</Label>
                    <Input 
                      value={formData.server}
                      onChange={(e) => setFormData(prev => ({ ...prev, server: e.target.value }))}
                      placeholder="e.g., ICMarkets-Live-04" 
                      className="bg-background/50 border-white/10 h-12 rounded-xl text-foreground font-medium" 
                    />
                  </div>
                </div>
              )}

              {showLoginFields && (
                <div className="space-y-6">
                   <div className="flex items-center gap-2 mb-2">
                     <User size={18} className="text-accent" />
                     <Label className="text-xs font-bold uppercase tracking-[0.2em] text-foreground/80">Account Authentication</Label>
                   </div>
                   <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      <div className="space-y-3">
                        <Label className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">Login ID / Email</Label>
                        <Input 
                          value={formData.login}
                          onChange={(e) => setFormData(prev => ({ ...prev, login: e.target.value }))}
                          placeholder="Account email or ID"
                          className="bg-background/50 border-white/10 h-12 rounded-xl text-foreground" 
                        />
                      </div>
                      <div className="space-y-3">
                        <Label className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">Master Password</Label>
                        <Input 
                          type="password" 
                          value={formData.password}
                          onChange={(e) => setFormData(prev => ({ ...prev, password: e.target.value }))}
                          className="bg-background/50 border-white/10 h-12 rounded-xl text-foreground" 
                        />
                      </div>
                   </div>
                </div>
              )}

              {showApiFields && (
                <div className="space-y-6">
                   <div className="flex items-center gap-2 mb-2">
                     <Activity size={18} className="text-accent" />
                     <Label className="text-xs font-bold uppercase tracking-[0.2em] text-foreground/80">API Node Credentials</Label>
                   </div>
                   <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      <div className="space-y-3">
                        <Label className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">API Key / Token</Label>
                        <Input 
                          value={formData.apiKey}
                          onChange={(e) => setFormData(prev => ({ ...prev, apiKey: e.target.value }))}
                          className="bg-background/50 border-white/10 h-12 rounded-xl text-foreground font-mono text-xs" 
                        />
                      </div>
                      {showTokenNameField ? (
                        <div className="space-y-3">
                          <Label className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">Token Name</Label>
                          <Input 
                            value={formData.tokenName}
                            onChange={(e) => setFormData(prev => ({ ...prev, tokenName: e.target.value }))}
                            placeholder="e.g., NexusBotToken"
                            className="bg-background/50 border-white/10 h-12 rounded-xl text-foreground font-medium" 
                          />
                        </div>
                      ) : (
                        <div className="space-y-3">
                          <Label className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">API Private Secret</Label>
                          <Input 
                            type="password" 
                            value={formData.secretToken}
                            onChange={(e) => setFormData(prev => ({ ...prev, secretToken: e.target.value }))}
                            className="bg-background/50 border-white/10 h-12 rounded-xl text-foreground font-mono text-xs" 
                          />
                        </div>
                      )}
                   </div>
                </div>
              )}

              {showTokenField && (
                <div className="space-y-6">
                   <div className="flex items-center gap-2 mb-2">
                     <Lock size={18} className="text-accent" />
                     <Label className="text-xs font-bold uppercase tracking-[0.2em] text-foreground/80">SSID / Session Token (Optional)</Label>
                   </div>
                   <div className="space-y-3">
                      <Label className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">Session SSID Token</Label>
                      <Input 
                        value={formData.token}
                        onChange={(e) => setFormData(prev => ({ ...prev, token: e.target.value }))}
                        placeholder="Paste SSID from browser cookies"
                        className="bg-background/50 border-white/10 h-12 rounded-xl text-foreground font-mono text-xs" 
                      />
                   </div>
                </div>
              )}

              <div className="p-6 rounded-2xl bg-destructive/5 border border-destructive/20 flex items-start gap-5">
                <AlertTriangle className="h-6 w-6 text-destructive mt-0.5 shrink-0" />
                <div className="space-y-1">
                  <h4 className="text-sm font-bold text-destructive uppercase tracking-widest">Security Protocol</h4>
                  <p className="text-xs text-muted-foreground leading-relaxed font-medium">Your credentials are encrypted via AES-256. Nexus Pro works with both Demo and Real accounts.</p>
                </div>
              </div>
            </CardContent>
            <CardFooter className="bg-white/5 p-8 border-t border-white/5 flex justify-end gap-4">
               <Button className="bg-primary text-primary-foreground hover:bg-primary/90 px-10 h-12 rounded-xl shadow-xl shadow-primary/20 font-bold uppercase tracking-widest" onClick={handleSave} disabled={isSaving || loadingConfig}>
                 {isSaving ? (
                   <React.Fragment><RefreshCw className="h-4 w-4 mr-2 animate-spin" /> Handshaking...</React.Fragment>
                 ) : (
                   <React.Fragment><Save className="h-4 w-4 mr-2" /> Sync Nexus Node</React.Fragment>
                 )}
               </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="mobile" className="space-y-8 animate-in fade-in duration-500">
          <Card className="border-white/5 bg-card/60 shadow-2xl overflow-hidden">
            <CardHeader className="text-center pb-12 pt-12 border-b border-white/5 bg-primary/5">
              <div className="mx-auto h-20 w-20 bg-primary/20 rounded-3xl flex items-center justify-center mb-6 shadow-xl">
                <Smartphone className="h-10 w-10 text-primary" />
              </div>
              <CardTitle className="text-3xl font-bold text-foreground">Nexus Mobile Deployment</CardTitle>
            </CardHeader>
            <CardContent className="p-8 md:p-12 space-y-12 text-center">
              <p className="text-muted-foreground font-medium">Link this app as a PWA to your mobile device for on-the-go trading alerts.</p>
              <Button variant="outline" className="rounded-xl px-10 h-12 font-bold uppercase tracking-widest border-white/10 hover:bg-white/5">
                <SmartphoneNfc className="h-4 w-4 mr-2 text-accent" />
                Instructions for Android
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="guide" className="space-y-8 animate-in fade-in duration-500">
          <Card className="border-white/5 bg-card/40 backdrop-blur-sm shadow-2xl">
            <CardHeader className="p-10 border-b border-white/5">
              <CardTitle className="text-2xl font-bold">Setup Protocol</CardTitle>
            </CardHeader>
            <CardContent className="p-10 space-y-10">
              <div className="flex gap-8">
                <div className="h-12 w-12 rounded-2xl bg-primary text-primary-foreground flex items-center justify-center font-bold text-xl shrink-0">1</div>
                <div>
                   <h4 className="font-bold text-lg">Select Platform</h4>
                   <p className="text-sm text-muted-foreground">Choose your broker. MetaTrader users need their server name.</p>
                </div>
              </div>
              <div className="flex gap-8">
                <div className="h-12 w-12 rounded-2xl bg-white/5 text-muted-foreground flex items-center justify-center font-bold text-xl shrink-0 border border-white/10">2</div>
                <div>
                   <h4 className="font-bold text-lg">Account Mode</h4>
                   <p className="text-sm text-muted-foreground">Toggle between Demo for testing or Real for actual trading.</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}