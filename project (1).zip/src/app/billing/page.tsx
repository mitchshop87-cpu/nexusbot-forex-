
"use client"

import * as React from "react"
import { Check, Zap, Shield, Crown, RefreshCw, Calendar, ArrowRight, Smartphone, Coins, MessageCircle, Landmark, Hash, Send } from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { useToast } from "@/hooks/use-toast"
import { useFirestore, useUser, useDoc } from "@/firebase"
import { doc, setDoc, serverTimestamp } from "firebase/firestore"
import { errorEmitter } from "@/firebase/error-emitter"
import { FirestorePermissionError } from "@/firebase/errors"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

const plans = [
  {
    id: "free",
    name: "Starter",
    price: "$0",
    desc: "Test the waters with basic bot functions",
    features: ["1 Active Strategy", "Standard Latency (500ms)", "Manual Strategy Setup", "Desktop Only Notifications"],
    buttonText: "Current Plan",
  },
  {
    id: "pro",
    name: "Cloud Pro",
    price: "$49",
    period: "/mo",
    desc: "The sweet spot for serious traders",
    features: ["5 Active Strategies", "Low Latency (24ms)", "AI Strategy Generation", "Telegram Mobile Alerts", "24/7 Cloud Engine"],
    buttonText: "Upgrade to Pro",
    popular: true,
  },
  {
    id: "elite",
    name: "Elite AI",
    price: "$99",
    period: "/mo",
    desc: "Ultimate performance and priority execution",
    features: ["Unlimited Strategies", "Ultra-Low Latency (5ms)", "Custom AI Prompting", "Priority Market Access", "Dedicated Execution Node"],
    buttonText: "Go Elite",
  }
]

export default function BillingPage() {
  const { toast } = useToast()
  const db = useFirestore()
  const { user } = useUser()
  const [isUpdating, setIsUpdating] = React.useState<string | null>(null)

  const platformConfigRef = React.useMemo(() => doc(db, 'config', 'payment'), [db])
  const { data: platformConfig } = useDoc(platformConfigRef)

  const subRef = React.useMemo(() => {
    if (!db || !user) return null
    return doc(db, 'users', user.uid, 'config', 'subscription')
  }, [db, user])

  const { data: subData } = useDoc(subRef)
  const currentPlan = subData?.plan || "free"
  const currentStatus = subData?.status || "active"

  const handleUpgrade = (planId: string, isTrial: boolean = false) => {
    if (planId === currentPlan && !isTrial) return
    if (!subRef) return

    setIsUpdating(planId)
    
    const nextDate = new Date()
    nextDate.setDate(nextDate.getDate() + (isTrial ? 7 : 30))

    setDoc(subRef, {
      plan: planId,
      status: isTrial ? "trialing" : "active",
      nextBillingDate: nextDate.toISOString(),
      updatedAt: serverTimestamp()
    }, { merge: true })
      .then(() => {
        setIsUpdating(null)
        toast({
          title: isTrial ? "Trial Started" : "Subscription Updated",
          description: isTrial 
            ? `Your 7-day free trial of ${planId.toUpperCase()} is now live!` 
            : `You are now on the ${planId.toUpperCase()} plan.`
        })
      })
      .catch(async () => {
        setIsUpdating(null)
        const permissionError = new FirestorePermissionError({
          path: subRef.path,
          operation: 'update',
          requestResourceData: { plan: planId, status: isTrial ? "trialing" : "active" }
        })
        errorEmitter.emit('permission-error', permissionError)
      })
  }

  const handleWhatsAppChat = () => {
    const whatsappNum = platformConfig?.whatsappNumber || "+2347031335805";
    const cleanNumber = whatsappNum.replace(/[^\d]/g, '');
    window.open(`https://wa.me/${cleanNumber}?text=Hello%20Admin,%20I%20have%20made%20a%20payment%20for%20my%20Nexus%20Pro%20subscription.%20Here%20is%20my%20proof.`, '_blank');
  }

  const handleTelegramBot = () => {
    const botLink = platformConfig?.telegramBot || "@Fxaipro_bot";
    const cleanBot = botLink.replace('@', '');
    window.open(`https://t.me/${cleanBot}`, '_blank');
  }

  const handlePaymentRequest = (method: string) => {
    toast({
      title: "Action Required",
      description: `Please send your proof of payment via WhatsApp to the admin for activation.`
    })
    handleWhatsAppChat();
  }

  return (
    <div className="max-w-6xl mx-auto space-y-12 animate-in fade-in slide-in-from-bottom-4 duration-700 pb-20">
      <div className="text-center space-y-4">
        <Badge variant="outline" className="border-accent text-accent font-bold px-4 py-1 uppercase tracking-widest">Monetization Ready</Badge>
        <h1 className="text-4xl md:text-5xl font-headline font-bold tracking-tight text-foreground">Fuel Your 24/7 Cloud Engine</h1>
        <p className="text-muted-foreground text-lg max-w-2xl mx-auto">Select a professional tier to unlock autonomous execution. Supporting Bank Transfer, USSD, and Crypto.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {plans.map((plan) => (
          <Card key={plan.id} className={`relative border-white/5 bg-card/40 backdrop-blur-sm flex flex-col overflow-hidden transition-all hover:translate-y-[-4px] hover:shadow-2xl ${plan.popular ? 'border-primary/50 shadow-primary/10 ring-1 ring-primary/20' : ''}`}>
            {plan.popular && (
              <div className="absolute top-0 right-0">
                <div className="bg-primary text-primary-foreground text-[10px] font-bold uppercase tracking-widest px-6 py-1 rotate-45 translate-x-[25px] translate-y-[10px] shadow-lg">
                  Most Popular
                </div>
              </div>
            )}
            <CardHeader className="space-y-4">
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-xl ${plan.id === 'elite' ? 'bg-accent/10 text-accent' : 'bg-primary/10 text-primary'}`}>
                  {plan.id === 'free' ? <Zap size={24} /> : plan.id === 'pro' ? <Crown size={24} /> : <Shield size={24} />}
                </div>
                <CardTitle className="text-2xl font-bold text-foreground">{plan.name}</CardTitle>
              </div>
              <CardDescription>{plan.desc}</CardDescription>
              <div className="flex items-baseline gap-1 pt-2">
                <span className="text-4xl font-bold text-foreground">{plan.price}</span>
                <span className="text-muted-foreground font-medium">{plan.period}</span>
              </div>
            </CardHeader>
            <CardContent className="flex-1 space-y-4">
              <div className="space-y-3">
                {plan.features.map((feature, i) => (
                  <div key={i} className="flex items-start gap-3 text-sm">
                    <Check className="h-4 w-4 text-accent mt-0.5 shrink-0" />
                    <span className="text-muted-foreground font-medium">{feature}</span>
                  </div>
                ))}
              </div>
            </CardContent>
            <CardFooter className="pt-6">
              <Button 
                className={`w-full h-12 rounded-xl font-bold uppercase tracking-widest transition-all ${
                  currentPlan === plan.id ? 'bg-secondary cursor-default' : 'bg-primary text-primary-foreground hover:shadow-lg hover:shadow-primary/20'
                }`}
                disabled={currentPlan === plan.id || !!isUpdating}
                onClick={() => handleUpgrade(plan.id)}
              >
                {isUpdating === plan.id ? <RefreshCw className="h-4 w-4 animate-spin mr-2" /> : null}
                {currentPlan === plan.id ? (currentStatus === 'trialing' ? 'Active Trial' : 'Your Active Plan') : plan.buttonText}
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>

      <Card className="border-white/5 bg-card/40 backdrop-blur-sm overflow-hidden shadow-2xl">
        <CardHeader className="bg-white/5 p-8 border-b border-white/5">
          <CardTitle className="text-2xl font-bold">Manual & Alternative Payments</CardTitle>
          <CardDescription className="text-lg">Direct Bank Transfer, USSD, and Mobile Money options for rapid activation.</CardDescription>
        </CardHeader>
        <CardContent className="p-8">
          <Tabs defaultValue="bank" className="w-full">
            <TabsList className="grid w-full grid-cols-3 bg-white/5 p-1 mb-8">
              <TabsTrigger value="bank" className="font-bold">Bank & USSD</TabsTrigger>
              <TabsTrigger value="local" className="font-bold">Mobile Money</TabsTrigger>
              <TabsTrigger value="crypto" className="font-bold">Cryptocurrency</TabsTrigger>
            </TabsList>
            
            <TabsContent value="bank" className="space-y-8 animate-in fade-in duration-500">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="p-8 rounded-3xl bg-white/5 border border-white/5 space-y-6">
                  <div className="flex items-center gap-4">
                    <div className="p-3 bg-blue-500/10 text-blue-500 rounded-2xl">
                      <Landmark size={24} />
                    </div>
                    <div>
                      <h4 className="font-bold text-lg">Direct Bank Transfer</h4>
                      <p className="text-xs text-muted-foreground uppercase font-bold tracking-widest">Manual Verification</p>
                    </div>
                  </div>
                  <div className="space-y-3 p-6 bg-background/50 rounded-2xl border border-white/5">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">Bank Name:</span>
                      <span className="font-bold text-foreground">{platformConfig?.bankName || "Firstbank Nigeria"}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">Account Number:</span>
                      <span className="font-bold font-mono text-lg tracking-widest text-primary">{platformConfig?.accountNumber || "3082143955"}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">Account Name:</span>
                      <span className="font-bold text-foreground uppercase text-xs">{platformConfig?.accountName || "Nexus Pro Admin"}</span>
                    </div>
                  </div>
                  <Button variant="outline" className="w-full h-12 rounded-xl gap-2 border-white/10 hover:bg-white/5 font-bold" onClick={() => handlePaymentRequest('Bank Transfer')}>
                    I've Transferred Funds
                  </Button>
                </div>
                
                <div className="p-8 rounded-3xl bg-white/5 border border-white/5 space-y-6">
                  <div className="flex items-center gap-4">
                    <div className="p-3 bg-purple-500/10 text-purple-500 rounded-2xl">
                      <Hash size={24} />
                    </div>
                    <div>
                      <h4 className="font-bold text-lg">Instant USSD Code</h4>
                      <p className="text-xs text-muted-foreground uppercase font-bold tracking-widest">Offline Activation</p>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground leading-relaxed">The fastest offline way to pay without internet access. Dial this on your mobile line.</p>
                  <div className="bg-background/80 p-8 rounded-2xl border border-white/10 text-center shadow-inner">
                    <span className="text-2xl font-bold font-mono tracking-[0.2em] text-accent">
                      {platformConfig?.ussdCode || "*894*3082143955*AMOUNT#"}
                    </span>
                  </div>
                  <Button variant="outline" className="w-full h-12 rounded-xl gap-2 border-white/10 hover:bg-white/5 font-bold" onClick={() => handlePaymentRequest('USSD')}>
                    Verify USSD Transaction
                  </Button>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="local" className="space-y-8 animate-in fade-in duration-500">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="p-8 rounded-3xl bg-white/5 border border-white/5 space-y-6">
                  <div className="flex items-center gap-4">
                    <div className="p-3 bg-blue-500/10 text-blue-500 rounded-2xl">
                      <Smartphone size={24} />
                    </div>
                    <div>
                      <h4 className="font-bold text-lg">Paystack / Flutterwave</h4>
                      <p className="text-xs text-muted-foreground uppercase font-bold tracking-widest">Debit Card / MoMo</p>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground leading-relaxed">Pay instantly via local Gateways. Supports MTN MoMo, Airtel Money, and all local bank cards.</p>
                  <Button variant="outline" className="w-full h-12 rounded-xl gap-2 border-white/10 hover:bg-white/5 font-bold" onClick={() => handlePaymentRequest('Paystack')}>
                    Proceed to Gateway
                  </Button>
                </div>
                <div className="p-8 rounded-3xl bg-white/5 border border-white/5 space-y-6">
                  <div className="flex items-center gap-4">
                    <div className="p-3 bg-green-500/10 text-green-500 rounded-2xl">
                      <MessageCircle size={24} />
                    </div>
                    <div>
                      <h4 className="font-bold text-lg">Direct Activation</h4>
                      <p className="text-xs text-muted-foreground uppercase font-bold tracking-widest">Support Center</p>
                    </div>
                  </div>
                  <div className="flex flex-col gap-2">
                    <Button variant="outline" className="w-full h-12 rounded-xl gap-2 border-white/10 hover:bg-white/5 font-bold" onClick={handleWhatsAppChat}>
                      Chat on WhatsApp
                    </Button>
                    <Button variant="outline" className="w-full h-12 rounded-xl gap-2 border-white/10 hover:bg-white/5 font-bold" onClick={handleTelegramBot}>
                      <Send className="h-4 w-4" /> Telegram: {platformConfig?.telegramBot || "@Fxaipro_bot"}
                    </Button>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="crypto" className="animate-in fade-in duration-500">
              <div className="p-12 rounded-3xl bg-white/5 border border-white/5 text-center space-y-8 max-w-2xl mx-auto">
                <div className="flex justify-center">
                  <div className="p-6 bg-orange-500/10 text-orange-500 rounded-3xl shadow-xl shadow-orange-500/5">
                    <Coins size={64} />
                  </div>
                </div>
                <div className="space-y-3">
                  <h3 className="text-2xl font-bold text-foreground">Secure USDT (TRC20) Payment</h3>
                  <p className="text-sm text-muted-foreground max-w-sm mx-auto">Pay using USDT for instant global activation. Lowest fees via Tron Network.</p>
                </div>
                <div className="flex flex-col items-center gap-6">
                   <div className="bg-background/80 p-6 rounded-2xl border border-white/10 font-mono text-sm select-all tracking-wider text-primary shadow-inner break-all w-full max-w-md">
                     {platformConfig?.usdtAddress || "TRS3HuiKEW1BLZPhGJAAzxSGgf9XrcraZJ"}
                   </div>
                   <Button className="bg-primary text-primary-foreground font-bold px-12 h-12 rounded-xl uppercase tracking-widest" onClick={() => handlePaymentRequest('Crypto')}>
                     I have sent the USDT
                   </Button>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Card className="border-white/5 bg-card/60 shadow-xl overflow-hidden">
          <CardHeader>
            <CardTitle className="text-xl font-bold flex items-center gap-2">
              <RefreshCw className="h-5 w-5 text-accent" />
              Usage Summary
            </CardTitle>
            <CardDescription>Monitor your current plan limits</CardDescription>
          </CardHeader>
          <CardContent className="space-y-8">
             <div className="space-y-3">
               <div className="flex justify-between text-sm font-bold">
                 <span className="text-muted-foreground uppercase tracking-widest text-[10px]">Strategies Active</span>
                 <span>1 / {currentPlan === 'free' ? '1' : currentPlan === 'pro' ? '5' : '∞'}</span>
               </div>
               <Progress value={currentPlan === 'free' ? 100 : 20} className="h-2 bg-white/5" />
             </div>
             <div className="p-6 rounded-2xl bg-accent/5 border border-accent/10 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <Calendar className="h-6 w-6 text-accent" />
                  <div className="space-y-1">
                    <p className="text-[10px] text-muted-foreground uppercase font-bold tracking-widest">
                      {currentStatus === 'trialing' ? 'Trial Expiry' : 'Next Billing Date'}
                    </p>
                    <p className="text-sm font-bold text-foreground">{subData?.nextBillingDate ? new Date(subData.nextBillingDate).toLocaleDateString() : "No active cycle"}</p>
                  </div>
                </div>
                <Button variant="ghost" className="text-accent text-[10px] font-bold uppercase tracking-widest">History</Button>
             </div>
          </CardContent>
        </Card>

        <Card className="border-white/5 bg-primary/5 shadow-xl relative overflow-hidden group">
          <div className="absolute -right-10 -bottom-10 opacity-5 group-hover:rotate-12 transition-transform duration-700">
            <Zap size={200} />
          </div>
          <CardHeader>
            <CardTitle className="text-2xl font-bold text-foreground">Risk-Free Evaluation</CardTitle>
            <CardDescription className="text-foreground/70 text-lg">Start a 7-day trial of our Cloud Pro features. No credit card required.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
             <div className="space-y-4">
               <div className="flex gap-4 p-4 rounded-2xl bg-white/5 border border-white/5">
                 <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center shrink-0">
                   <Check className="text-primary h-5 w-5" />
                 </div>
                 <div>
                   <h4 className="font-bold text-foreground">7-Day Cloud Pro Access</h4>
                   <p className="text-xs text-muted-foreground">Test all premium AI generation and low-latency execution.</p>
                 </div>
               </div>
             </div>
             <Button 
               className="w-full h-14 gap-2 bg-white text-primary hover:bg-white/90 font-bold uppercase tracking-widest group rounded-2xl shadow-xl"
               onClick={() => handleUpgrade('pro', true)}
               disabled={!!isUpdating || currentPlan === 'pro' || currentPlan === 'elite'}
             >
               {isUpdating === 'pro' ? <RefreshCw className="h-4 w-4 animate-spin mr-2" /> : <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />}
               {currentStatus === 'trialing' ? 'Trial Active' : 'Activate 7-Day Free Trial'}
             </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
