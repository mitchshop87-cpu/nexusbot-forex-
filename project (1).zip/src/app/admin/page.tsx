
"use client"

import * as React from "react"
import { 
  Users, 
  DollarSign, 
  ShieldCheck, 
  Search, 
  CreditCard,
  Crown,
  Activity,
  Smartphone,
  Coins,
  CheckCircle2,
  XCircle,
  Landmark,
  Hash,
  Save,
  RefreshCw,
  Lock,
  ArrowRight,
  Send
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Label } from "@/components/ui/label"
import { useFirestore, useDoc } from "@/firebase"
import { doc, setDoc } from "firebase/firestore"
import { useToast } from "@/hooks/use-toast"

export default function AdminDashboard() {
  const [isAuthenticated, setIsAuthenticated] = React.useState(false)
  const [password, setPassword] = React.useState("")
  const [authError, setAuthError] = React.useState(false)
  
  const db = useFirestore()
  const { toast } = useToast()
  
  const paymentConfigRef = React.useMemo(() => {
    if (!db) return null
    return doc(db, 'config', 'payment')
  }, [db])
  
  const { data: paymentConfig } = useDoc(paymentConfigRef)
  
  const [isSaving, setIsSaving] = React.useState(false)
  const [formData, setFormData] = React.useState({
    bankName: "Firstbank Nigeria",
    accountNumber: "3082143955",
    accountName: "Nexus Pro Admin",
    ussdCode: "*894*3082143955*AMOUNT#",
    usdtAddress: "TRS3HuiKEW1BLZPhGJAAzxSGgf9XrcraZJ",
    whatsappNumber: "+2347031335805",
    telegramBot: "@Fxaipro_bot"
  })

  React.useEffect(() => {
    if (paymentConfig) {
      setFormData({
        bankName: paymentConfig.bankName || "Firstbank Nigeria",
        accountNumber: paymentConfig.accountNumber || "3082143955",
        accountName: paymentConfig.accountName || "Nexus Pro Admin",
        ussdCode: paymentConfig.ussdCode || "*894*3082143955*AMOUNT#",
        usdtAddress: paymentConfig.usdtAddress || "TRS3HuiKEW1BLZPhGJAAzxSGgf9XrcraZJ",
        whatsappNumber: paymentConfig.whatsappNumber || "+2347031335805",
        telegramBot: paymentConfig.telegramBot || "@Fxaipro_bot"
      })
    }
  }, [paymentConfig])

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()
    if (password === "NexusPro#2025") {
      setIsAuthenticated(true)
      setAuthError(false)
    } else {
      setAuthError(true)
      toast({
        variant: "destructive",
        title: "Access Denied",
        description: "Invalid admin credentials."
      })
    }
  }

  const handleSaveConfig = () => {
    if (!paymentConfigRef) return
    setIsSaving(true)
    setDoc(paymentConfigRef, formData, { merge: true })
      .then(() => {
        setIsSaving(false)
        toast({
          title: "Settings Saved",
          description: "Terminal configuration has been updated globally."
        })
      })
      .catch(() => {
        setIsSaving(false)
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to save configuration."
        })
      })
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-[80vh] flex items-center justify-center p-4">
        <Card className="w-full max-w-md border-white/5 bg-card/60 backdrop-blur-xl shadow-2xl overflow-hidden">
          <div className="bg-primary/10 p-8 text-center border-b border-white/5">
            <div className="mx-auto h-16 w-16 bg-primary/20 rounded-2xl flex items-center justify-center mb-4">
              <Lock className="h-8 w-8 text-primary" />
            </div>
            <CardTitle className="text-2xl font-bold">Admin Portal</CardTitle>
            <CardDescription>Enter security key to access platform controls.</CardDescription>
          </div>
          <CardContent className="p-8 pt-10">
            <form onSubmit={handleLogin} className="space-y-6">
              <div className="space-y-2">
                <Label className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Master Security Key</Label>
                <Input 
                  type="password" 
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className={`bg-background/50 border-white/10 h-12 rounded-xl text-center text-lg tracking-widest ${authError ? 'border-destructive ring-1 ring-destructive' : ''}`}
                  autoFocus
                />
              </div>
              <Button type="submit" className="w-full h-12 bg-primary text-primary-foreground font-bold uppercase tracking-widest rounded-xl shadow-lg shadow-primary/20 group">
                Unlock Terminal
                <ArrowRight className="h-4 w-4 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
            </form>
          </CardContent>
          <div className="bg-white/5 p-4 text-center">
             <p className="text-[10px] text-muted-foreground uppercase font-bold tracking-widest">Protected by 256-bit AI Encryption</p>
          </div>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-8 animate-in fade-in duration-700">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-headline font-bold tracking-tight text-foreground">Platform Admin</h1>
          <p className="text-muted-foreground mt-1 text-lg">Manage subscriptions and configure platform-wide payment details.</p>
        </div>
        <div className="flex gap-2">
          <Badge className="bg-primary/20 text-primary border-primary/20 px-3 py-1 font-bold">OWNER ACCESS GRANTED</Badge>
          <Button variant="ghost" size="sm" onClick={() => setIsAuthenticated(false)} className="text-[10px] font-bold uppercase tracking-widest h-auto p-2 hover:bg-white/5">Logout</Button>
        </div>
      </div>

      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full md:w-[400px] grid-cols-2 bg-white/5 p-1 mb-6">
          <TabsTrigger value="overview">Users & Payments</TabsTrigger>
          <TabsTrigger value="setup">Global Setup</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <Card className="lg:col-span-2 border-white/5 bg-card/40 backdrop-blur-sm overflow-hidden shadow-xl">
            <CardHeader className="flex flex-row items-center justify-between pb-6 border-b border-white/5">
              <div>
                <CardTitle className="text-xl">Subscription Audit</CardTitle>
                <CardDescription>Verify manual payments (Bank, USSD, USDT)</CardDescription>
              </div>
              <div className="relative w-full max-w-xs hidden md:block">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input placeholder="Search user email..." className="pl-10 bg-background/50 border-white/10" />
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader className="bg-white/5">
                  <TableRow className="border-white/5 hover:bg-transparent">
                    <TableHead className="text-[10px] uppercase font-bold text-muted-foreground tracking-widest pl-6">Customer</TableHead>
                    <TableHead className="text-[10px] uppercase font-bold text-muted-foreground tracking-widest">Plan</TableHead>
                    <TableHead className="text-[10px] uppercase font-bold text-muted-foreground tracking-widest">Method</TableHead>
                    <TableHead className="text-[10px] uppercase font-bold text-muted-foreground tracking-widest">Status</TableHead>
                    <TableHead className="text-[10px] uppercase font-bold text-muted-foreground tracking-widest text-right pr-6">Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TableRow className="border-white/5 hover:bg-white/5 transition-colors group">
                    <TableCell className="pl-6">
                      <div className="font-bold text-foreground">John Doe</div>
                      <div className="text-xs text-muted-foreground">john@example.com</div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary" className="text-[10px] font-bold uppercase tracking-widest">Elite</Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2 text-xs text-foreground/80">
                        <Coins className="h-3 w-3 text-orange-400" /> USDT
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="text-[10px] font-bold text-accent border-accent/20 bg-accent/5">Active</Badge>
                    </TableCell>
                    <TableCell className="text-right pr-6">
                       <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">Verified</span>
                    </TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          <Card className="border-white/5 bg-primary/5 shadow-xl">
            <CardHeader>
              <CardTitle className="text-lg">Revenue Mix</CardTitle>
              <CardDescription>Performance by payment channel</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
               <div className="space-y-2">
                 <div className="flex justify-between text-sm">
                   <span className="text-muted-foreground font-medium">Global Gateways</span>
                   <span className="font-bold">45%</span>
                 </div>
                 <div className="h-2 w-full bg-white/5 rounded-full overflow-hidden">
                   <div className="h-full bg-primary" style={{ width: '45%' }} />
                 </div>
               </div>
               <div className="space-y-2">
                 <div className="flex justify-between text-sm">
                   <span className="text-muted-foreground font-medium">Bank / USSD / Local</span>
                   <span className="font-bold">35%</span>
                 </div>
                 <div className="h-2 w-full bg-white/5 rounded-full overflow-hidden">
                   <div className="h-full bg-accent" style={{ width: '35%' }} />
                 </div>
               </div>
               <div className="space-y-2">
                 <div className="flex justify-between text-sm">
                   <span className="text-muted-foreground font-medium">Crypto (USDT)</span>
                   <span className="font-bold">20%</span>
                 </div>
                 <div className="h-2 w-full bg-white/5 rounded-full overflow-hidden">
                   <div className="h-full bg-orange-400" style={{ width: '20%' }} />
                 </div>
               </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="setup" className="max-w-3xl mx-auto space-y-6">
          <Card className="border-white/5 bg-card/60 shadow-2xl">
            <CardHeader>
              <CardTitle>Global Terminal Configuration</CardTitle>
              <CardDescription>Configure the default credentials shown to users.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label className="text-xs font-bold uppercase text-muted-foreground tracking-widest">Bank Name</Label>
                  <Input 
                    value={formData.bankName}
                    onChange={(e) => setFormData({...formData, bankName: e.target.value})}
                    className="bg-background/50 border-white/10 h-12 rounded-xl"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-xs font-bold uppercase text-muted-foreground tracking-widest">Account Name</Label>
                  <Input 
                    value={formData.accountName}
                    onChange={(e) => setFormData({...formData, accountName: e.target.value})}
                    className="bg-background/50 border-white/10 h-12 rounded-xl"
                  />
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label className="text-xs font-bold uppercase text-muted-foreground tracking-widest">Account Number</Label>
                  <Input 
                    value={formData.accountNumber}
                    onChange={(e) => setFormData({...formData, accountNumber: e.target.value})}
                    className="bg-background/50 border-white/10 h-12 rounded-xl font-mono"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-xs font-bold uppercase text-muted-foreground tracking-widest">USSD Formula</Label>
                  <Input 
                    value={formData.ussdCode}
                    onChange={(e) => setFormData({...formData, ussdCode: e.target.value})}
                    className="bg-background/50 border-white/10 h-12 rounded-xl"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label className="text-xs font-bold uppercase text-muted-foreground tracking-widest">USDT (TRC20) Wallet</Label>
                <Input 
                  value={formData.usdtAddress}
                  onChange={(e) => setFormData({...formData, usdtAddress: e.target.value})}
                  className="bg-background/50 border-white/10 h-12 rounded-xl font-mono text-xs"
                />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label className="text-xs font-bold uppercase text-muted-foreground tracking-widest">WhatsApp Support</Label>
                  <Input 
                    value={formData.whatsappNumber}
                    onChange={(e) => setFormData({...formData, whatsappNumber: e.target.value})}
                    className="bg-background/50 border-white/10 h-12 rounded-xl"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-xs font-bold uppercase text-muted-foreground tracking-widest">Telegram Bot Link</Label>
                  <Input 
                    value={formData.telegramBot}
                    onChange={(e) => setFormData({...formData, telegramBot: e.target.value})}
                    placeholder="@Fxaipro_bot"
                    className="bg-background/50 border-white/10 h-12 rounded-xl"
                  />
                </div>
              </div>
            </CardContent>
            <CardFooter className="border-t border-white/5 p-8 flex justify-end">
              <Button onClick={handleSaveConfig} disabled={isSaving} className="h-12 px-8 rounded-xl gap-2 bg-primary text-primary-foreground font-bold uppercase tracking-widest">
                {isSaving ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                Save Platform Config
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
