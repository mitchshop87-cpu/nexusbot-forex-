
"use client"

import * as React from "react"
import { Send, Bell, Shield, Smartphone, ExternalLink, Zap, CheckCircle2, AlertCircle } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/hooks/use-toast"
import { useFirestore, useUser, useDoc } from "@/firebase"
import { doc, setDoc } from "firebase/firestore"
import { errorEmitter } from "@/firebase/error-emitter"
import { FirestorePermissionError } from "@/firebase/errors"

export default function NotificationsPage() {
  const { toast } = useToast()
  const db = useFirestore()
  const { user } = useUser()
  
  const [token, setToken] = React.useState("")
  const [chatId, setChatId] = React.useState("")
  const [isConnecting, setIsConnecting] = React.useState(false)
  const [isConnected, setIsConnected] = React.useState(false)

  const telegramRef = React.useMemo(() => {
    if (!db || !user) return null
    return doc(db, 'users', user.uid, 'config', 'telegram')
  }, [db, user])

  const { data: telegramData } = useDoc(telegramRef)

  React.useEffect(() => {
    if (telegramData) {
      setToken(telegramData.botToken || "")
      setChatId(telegramData.chatId || "")
      setIsConnected(!!(telegramData.botToken && telegramData.chatId))
    }
  }, [telegramData])

  const handleTestConnection = () => {
    if (!token || !chatId) {
      toast({
        variant: "destructive",
        title: "Missing Information",
        description: "Please enter both Bot Token and Chat ID."
      })
      return
    }

    setIsConnecting(true)
    
    if (telegramRef) {
      setDoc(telegramRef, {
        botToken: token,
        chatId: chatId,
        updatedAt: new Date().toISOString()
      }, { merge: true })
        .then(() => {
          setTimeout(() => {
            setIsConnecting(false)
            setIsConnected(true)
            toast({
              title: "Connection Successful",
              description: "Test alert sent to your Telegram chat."
            })
          }, 1500)
        })
        .catch(async () => {
          setIsConnecting(false)
          const permissionError = new FirestorePermissionError({
            path: telegramRef.path,
            operation: 'update',
            requestResourceData: { botToken: token, chatId: chatId }
          })
          errorEmitter.emit('permission-error', permissionError)
        })
    }
  }

  const handleOpenBot = () => {
    window.open(`https://t.me/Fxaipro_bot`, '_blank');
  }

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-headline font-bold tracking-tight">Telegram Alerts</h1>
          <p className="text-muted-foreground mt-1 text-lg">Receive real-time trade updates via @Fxaipro_bot</p>
        </div>
        {isConnected && (
          <Badge className="bg-accent/20 text-accent border-accent/20 gap-1.5 py-1 px-3">
            <div className="h-1.5 w-1.5 rounded-full bg-accent animate-pulse" />
            LIVE LINK ACTIVE
          </Badge>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
        <div className="md:col-span-7 space-y-6">
          <Card className="border-white/5 bg-card/60 shadow-xl">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Send className="h-5 w-5 text-primary" />
                Bot Configuration
              </CardTitle>
              <CardDescription>Link your Telegram bot to receive Nexus Pro signals</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4 p-4 rounded-2xl bg-white/5 border border-white/5">
                <div className="space-y-2">
                  <Label className="text-xs font-bold uppercase text-muted-foreground">Bot Token (from @BotFather)</Label>
                  <Input 
                    placeholder="123456789:ABCDefgh..." 
                    type="password"
                    className="bg-background/50 border-white/10"
                    value={token}
                    onChange={(e) => setToken(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-xs font-bold uppercase text-muted-foreground">Your Chat ID</Label>
                  <Input 
                    placeholder="987654321" 
                    className="bg-background/50 border-white/10"
                    value={chatId}
                    onChange={(e) => setChatId(e.target.value)}
                  />
                </div>
              </div>
              <Button 
                className={`w-full h-12 gap-2 ${isConnected ? 'bg-secondary' : 'bg-primary text-primary-foreground'}`}
                onClick={handleTestConnection}
                disabled={isConnecting}
              >
                {isConnecting ? "Validating..." : isConnected ? "Refresh Link" : "Link @Fxaipro_bot"}
              </Button>
            </CardContent>
          </Card>

          <Card className="border-white/5 bg-card/60 shadow-xl">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bell className="h-5 w-5 text-accent" />
                Notification Preferences
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <NotificationToggle title="Trade Entries" desc="Alert when a position is opened" defaultChecked />
              <NotificationToggle title="Trade Exits" desc="Alert with final P&L" defaultChecked />
              <NotificationToggle title="Daily Summary" desc="End-of-day performance report" defaultChecked />
            </CardContent>
          </Card>
        </div>

        <div className="md:col-span-5 space-y-6">
          <Card className="border-white/5 bg-card/60 shadow-xl overflow-hidden">
            <div className="bg-primary/10 p-6 flex items-center justify-center">
              <div className="relative">
                <div className="h-48 w-32 bg-slate-900 rounded-3xl border-4 border-slate-800 shadow-2xl flex items-center justify-center">
                   <Send className="h-12 w-12 text-primary" />
                </div>
              </div>
            </div>
            <CardHeader>
              <CardTitle className="text-xl">Fast Connect</CardTitle>
              <CardDescription>Direct access to the official bot</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
               <p className="text-sm text-muted-foreground">Start the bot and send <strong>/myid</strong> to get your Chat ID instantly.</p>
               <Button variant="outline" className="w-full gap-2 border-primary/20 hover:bg-primary/10" onClick={handleOpenBot}>
                 Open @Fxaipro_bot
               </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

function NotificationToggle({ title, desc, defaultChecked }: any) {
  return (
    <div className="flex items-center justify-between p-4 rounded-2xl bg-white/5 border border-white/5">
      <div className="space-y-0.5">
        <Label className="text-sm font-bold">{title}</Label>
        <p className="text-xs text-muted-foreground">{desc}</p>
      </div>
      <Switch defaultChecked={defaultChecked} />
    </div>
  )
}
