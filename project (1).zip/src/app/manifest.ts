
import { MetadataRoute } from 'next'

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: 'Nexus Pro Trading Bot',
    short_name: 'Nexus Pro',
    description: 'Autonomous AI Trading Bot for Forex and Binary Options',
    start_url: '/',
    display: 'standalone',
    background_color: '#1a1d24',
    theme_color: '#4dabf7',
    id: 'com.nexus.pro',
    icons: [
      {
        src: 'https://picsum.photos/seed/nexus-pro-v1/192/192',
        sizes: '192x192',
        type: 'image/png',
      },
      {
        src: 'https://picsum.photos/seed/nexus-pro-v1/512/512',
        sizes: '512x512',
        type: 'image/png',
      },
    ],
  }
}
