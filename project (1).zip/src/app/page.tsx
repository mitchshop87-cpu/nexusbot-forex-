
"use client"

import * as React from "react"
import { 
  TrendingUp, 
  Wallet, 
  Activity,
  ArrowUpRight,
  ArrowDownRight,
  Target,
  CheckCircle2,
  ChevronRight,
  ShieldCheck,
  Timer,
  Terminal as TerminalIcon,
  Cloud,
  Signal,
  Crown,
  CalendarDays,
  Clock
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer
} from "recharts"
import Link from "next/link"
import { useFirestore, useUser, useCollection, useDoc, useMemoFirebase } from "@/firebase"
import { collection, doc, query, orderBy, limit } from "firebase/firestore"
import { AdBanner } from "@/components/ads/ad-banner"

const chartData = [
  { time: "09:00", balance: 10200 },
  { time: "10:00", balance: 10150 },
  { time: "11:00", balance: 10300 },
  { time: "12:00", balance: 10280 },
  { time: "13:00", balance: 10450 },
  { time: "14:00", balance: 10400 },
  { time: "15:00", balance: 10600 },
  { time: "16:00", balance: 10550 },
  { time: "17:00", balance: 10700 },
]

export default function Dashboard() {
  const [livePrice, setLivePrice] = React.useState(1.0854)
  const [showChecklist, setShowChecklist] = React.useState(true)
  const { user } = useUser()
  const db = useFirestore()

  const subRef = React.useMemo(() => {
    if (!db || !user) return null
    return doc(db, 'users', user.uid, 'config', 'subscription')
  }, [db, user])
  const { data: subData } = useDoc(subRef)
  const currentPlan = subData?.plan || "free"
  const isTrialing = subData?.status === 'trialing'

  const [daysLeft, setDaysLeft] = React.useState<number | null>(null)

  React.useEffect(() => {
    if (isTrialing && subData?.nextBillingDate) {
      const trialEndsAt = new Date(subData.nextBillingDate)
      const diff = trialEndsAt.getTime() - new Date().getTime()
      setDaysLeft(Math.max(0, Math.ceil(diff / (1000 * 60 * 60 * 24))))
    }
  }, [isTrialing, subData])

  const tradesRef = useMemoFirebase(() => {
    if (!db || !user) return null
    return collection(db, 'users', user.uid, 'trades')
  }, [db, user])
  const { data: trades } = useCollection(tradesRef)

  const logsQuery = useMemoFirebase(() => {
    if (!db || !user) return null
    return query(collection(db, 'users', user.uid, 'logs'), orderBy('timestamp', 'desc'), limit(10))
  }, [db, user])
  const { data: logs } = useCollection(logsQuery)

  const brokerRef = useMemoFirebase(() => {
    if (!db || !user) return null
    return doc(db, 'users', user.uid, 'config', 'broker')
  }, [db, user])
  const { data: brokerConfig } = useDoc(brokerRef)

  const telegramRef = useMemoFirebase(() => {
    if (!db || !user) return null
    return doc(db, 'users', user.uid, 'config', 'telegram')
  }, [db, user])
  const { data: telegramConfig } = useDoc(telegramRef)

  const strategyQuery = useMemoFirebase(() => {
    if (!db || !user) return null
    return query(collection(db, 'users', user.uid, 'strategies'), limit(1))
  }, [db, user])
  const { data: strategies } = useCollection(strategyQuery)
  const activeStrategy = strategies?.find(s => s.isActive)

  React.useEffect(() => {
    const interval = setInterval(() => {
      setLivePrice((prev: number) => prev + (Math.random() - 0.5) * 0.0005)
    }, 2000)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="space-y-8 animate-in fade-in duration-700">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-3xl font-headline font-bold tracking-tight text-foreground">Nexus Terminal</h1>
            {currentPlan !== 'free' && (
              <Badge className="bg-primary/20 text-primary border-primary/20 gap-1.5 font-bold">
                <Crown size={12} className="fill-primary" /> {currentPlan.toUpperCase()}
              </Badge>
            )}
            {isTrialing && (
              <Badge variant="outline" className="border-accent/50 text-accent flex gap-1.5 items-center font-bold">
                <CalendarDays size={14} />
                {daysLeft} Days Trial Left
              </Badge>
            )}
          </div>
          <p className="text-muted-foreground mt-1 text-lg">Nexus Pro v1.0.0 • Autonomous Intelligence</p>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-4 bg-card border rounded-2xl p-2 px-6 shadow-xl border-white/5">
            <div className="flex flex-col items-end">
              <span className="text-[10px] uppercase font-bold text-muted-foreground tracking-widest">Market Feed</span>
              <span className="font-mono font-bold text-accent text-xl">{livePrice.toFixed(4)}</span>
            </div>
            <div className="h-10 w-px bg-white/5 mx-2" />
            <div className="flex flex-col items-start">
              <div className="flex items-center gap-2">
                <div className={`h-2 w-2 rounded-full ${activeStrategy?.isActive ? 'bg-accent animate-pulse' : 'bg-muted-foreground'}`} />
                <span className="text-[10px] uppercase font-bold text-muted-foreground tracking-widest">Nexus Brain</span>
              </div>
              <Badge variant="outline" className={`${activeStrategy?.isActive ? 'bg-accent/10 text-accent border-accent/20' : 'bg-muted/10 text-muted border-white/10'} font-bold px-4 py-1 mt-1`}>
                {activeStrategy?.isActive ? 'SYNCED' : 'STANDBY'}
              </Badge>
            </div>
          </div>
        </div>
      </div>

      {showChecklist && (
        <Card className="border-accent/30 bg-accent/[0.03] shadow-2xl overflow-hidden relative group">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShieldCheck className="h-5 w-5 text-accent" />
                <CardTitle className="text-lg">Nexus Readiness Protocol</CardTitle>
              </div>
              <Button variant="ghost" size="sm" onClick={() => setShowChecklist(false)} className="text-[10px] font-bold uppercase tracking-widest h-auto p-0 hover:bg-transparent text-muted-foreground hover:text-foreground">Dismiss</Button>
            </div>
            <CardDescription className="text-foreground/70 font-medium">Complete these modules to enable full 24/7 autonomous Nexus execution.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-4">
              <ChecklistItem title="Broker Linked" completed={!!brokerConfig} link="/settings" />
              <ChecklistItem title="AI Strategy" completed={!!activeStrategy} link="/strategy" />
              <ChecklistItem title="Nexus Activation" completed={activeStrategy?.isActive} link="/strategy" />
              <ChecklistItem title="Mobile Sync" completed={!!telegramConfig} link="/notifications" />
            </div>
          </CardContent>
        </Card>
      )}

      {currentPlan === 'free' && (
        <div className="bg-primary/10 border border-primary/20 p-6 rounded-3xl flex flex-col md:flex-row items-center justify-between gap-4 shadow-xl">
          <div className="flex items-center gap-6">
            <div className="h-14 w-14 bg-primary/20 rounded-2xl flex items-center justify-center text-primary shadow-lg">
              <Crown size={32} />
            </div>
            <div>
              <p className="font-bold text-lg text-foreground">Upgrade to Nexus Pro for Strategy Builder</p>
              <p className="text-sm text-muted-foreground font-medium">Unlock 24/7 autonomous cloud execution and high-accuracy signals (m2 to 24h).</p>
            </div>
          </div>
          <Button size="lg" className="bg-primary text-primary-foreground font-bold px-10 rounded-xl h-12 uppercase tracking-widest shadow-xl shadow-primary/20" asChild>
            <Link href="/billing">Unlock Full Access</Link>
          </Button>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard title="Account Balance" value="$10,742.50" trend="+2.4%" trendType="up" icon={Wallet} />
        <StatCard title="Profit Today" value="+$342.10" trend="+$55.60" trendType="up" icon={TrendingUp} />
        <StatCard title="Win Rate" value="72.4%" trend="Live" trendType="neutral" icon={Activity} />
        <StatCard title="Active Trades" value={trades?.length || "0"} trend="Nexus Sync" trendType="neutral" icon={Target} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <Card className="shadow-2xl border-white/5 bg-card/40 backdrop-blur-sm flex flex-col overflow-hidden">
            <CardHeader className="pb-8 border-b border-white/5">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-2xl font-bold flex items-center gap-3">
                     <Activity className="h-6 w-6 text-primary" />
                     Growth Intelligence
                  </CardTitle>
                  <CardDescription className="text-lg">Real-time autonomous growth tracking (Timeframes: m2 - 24h)</CardDescription>
                </div>
                <div className="flex items-center gap-3 bg-white/5 px-4 py-2 rounded-xl">
                  <Signal className="h-4 w-4 text-accent animate-pulse" />
                  <span className="text-[10px] font-bold uppercase text-muted-foreground tracking-widest">Nexus Live</span>
                </div>
              </div>
            </CardHeader>
            <CardContent className="flex-1 p-8">
              <div className="h-[350px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={chartData}>
                    <defs>
                      <linearGradient id="colorBalance" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" opacity={0.3} />
                    <XAxis dataKey="time" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} />
                    <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value: any) => `$${value}`} domain={['dataMin - 100', 'dataMax + 100']} />
                    <Tooltip contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', borderRadius: '16px', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.3)' }} />
                    <Area type="monotone" dataKey="balance" stroke="hsl(var(--primary))" strokeWidth={4} fillOpacity={1} fill="url(#colorBalance)" animationDuration={1500} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
            <div className="p-8 border-t border-white/5 bg-white/[0.02]">
              <div className="flex items-center justify-between mb-6">
                 <div className="flex items-center gap-3">
                   <TerminalIcon className="h-5 w-5 text-accent" />
                   <h4 className="text-sm font-bold uppercase tracking-widest text-muted-foreground">Nexus Engine Feed</h4>
                 </div>
                 <Badge variant="outline" className="text-[10px] text-accent border-transparent animate-pulse font-bold">CORE v1.0.0 ACTIVE</Badge>
              </div>
              <ScrollArea className="h-32">
                <div className="space-y-3">
                  {logs && logs.length > 0 ? (
                    logs.map((log: any, i: number) => (
                      <div key={i} className="flex gap-4 text-xs font-mono">
                        <span className="text-muted-foreground/60">[{new Date(log.timestamp).toLocaleTimeString()}]</span>
                        <span className={log.type === 'trade' ? 'text-accent font-bold' : log.type === 'error' ? 'text-destructive font-bold' : 'text-foreground/80 font-medium'}>
                          {log.message}
                        </span>
                      </div>
                    ))
                  ) : (
                    <div className="space-y-3">
                      <MockLog message="Nexus Core Heartbeat: Stable (Latency: 18ms)" time="12:01:05" />
                      <MockLog message="Scanning Global Markets for Nexus signals..." time="12:01:10" />
                      <MockLog message="Protocol Check: m2 through 24h scan synchronized." time="12:01:15" />
                      <MockLog message="Auto-Execution Standby: Nexus Parameters Verified." time="12:01:25" />
                    </div>
                  )}
                </div>
              </ScrollArea>
            </div>
          </Card>
          
          <AdBanner />
        </div>

        <div className="space-y-8">
          <Card className="shadow-2xl border-white/5 bg-card/40 backdrop-blur-sm overflow-hidden">
            <CardHeader className="bg-white/5 border-b border-white/5">
              <div className="flex items-center justify-between">
                <CardTitle className="text-xl font-bold">Nexus Execution</CardTitle>
                <Badge className="bg-accent/20 text-accent border-accent/20">{(trades?.length || 0) > 0 ? trades?.length : 3} Nodes</Badge>
              </div>
              <CardDescription>Live Nexus-managed orders</CardDescription>
            </CardHeader>
            <CardContent className="p-6">
              <div className="space-y-6">
                {(trades?.length || 0) === 0 ? (
                  [
                    { id: 1, pair: "EUR/USD", type: "CALL", entry: "1.0854", pnl: "82%", duration: "m2", amount: "$50" },
                    { id: 2, pair: "GBP/JPY", type: "PUT", entry: "191.24", pnl: "85%", duration: "m15", amount: "$100" },
                    { id: 3, pair: "BTC/USD", type: "CALL", entry: "67240", pnl: "70%", duration: "1h", amount: "$25" }
                  ].map(pos => (
                    <PositionItem key={pos.id} {...pos} />
                  ))
                ) : (
                  trades?.map((trade: any) => (
                    <PositionItem key={trade.id} {...trade} />
                  ))
                )}
              </div>
            </CardContent>
          </Card>

          <Card className="border-white/5 bg-card/60 overflow-hidden shadow-xl">
            <CardHeader className="pb-4 border-b border-white/5">
              <CardTitle className="text-sm uppercase font-bold tracking-widest text-muted-foreground">Nexus Strategy Hub</CardTitle>
            </CardHeader>
            <CardContent className="p-6">
               {activeStrategy ? (
                 <div className="space-y-4">
                   <div className="flex justify-between items-center">
                     <span className="text-xs text-foreground font-bold uppercase tracking-widest">{activeStrategy.riskLevel} Risk Profile</span>
                     <span className="text-xs font-bold text-accent">{activeStrategy.recommendedAmount}% Stake</span>
                   </div>
                   <div className="flex items-center gap-2 text-xs font-bold text-primary">
                     <Clock size={14} />
                     Timeframe: {activeStrategy.duration || 'm5'}
                   </div>
                   <div className="p-4 rounded-2xl bg-white/5 border border-white/5">
                      <p className="text-xs text-muted-foreground italic leading-relaxed line-clamp-3">
                        "{activeStrategy.strategySummary}"
                      </p>
                   </div>
                   <Button variant="ghost" size="sm" className="w-full h-10 text-[10px] font-bold uppercase tracking-widest border border-white/5 rounded-xl hover:bg-white/5" asChild>
                     <Link href="/strategy">Optimize Nexus Brain</Link>
                   </Button>
                 </div>
               ) : (
                 <div className="text-center py-6">
                   <p className="text-sm text-muted-foreground mb-4">No active Nexus strategy found.</p>
                   <Button size="sm" className="h-10 px-8 text-xs font-bold uppercase tracking-widest rounded-xl" asChild>
                     <Link href="/strategy">Build Strategy</Link>
                   </Button>
                 </div>
               )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

function MockLog({ message, time }: { message: string, time: string }) {
  return (
    <div className="flex gap-4 text-[11px] font-mono">
      <span className="text-muted-foreground/60">[{time}]</span>
      <span className="text-foreground/80 font-medium">{message}</span>
    </div>
  )
}

function PositionItem({ pair, type, entry, pnl, amount, duration, expiry }: any) {
  const isCall = type === 'CALL' || type === 'BUY';
  return (
    <div className="flex items-center justify-between p-4 rounded-2xl border border-white/5 bg-white/5 hover:bg-white/10 transition-all group cursor-default shadow-sm">
      <div className="flex items-center gap-4">
        <div className={`p-3 rounded-xl shadow-lg ${isCall ? 'bg-accent/10' : 'bg-destructive/10'}`}>
          {isCall ? <ArrowUpRight className="h-6 w-6 text-accent" /> : <ArrowDownRight className="h-6 w-6 text-destructive" />}
        </div>
        <div>
          <div className="font-bold text-foreground flex items-center gap-2">
            {pair}
            <Badge variant="outline" className="text-[10px] font-bold h-4 px-1.5 opacity-60">{amount}</Badge>
          </div>
          <div className="text-xs text-muted-foreground font-medium flex items-center gap-2 mt-0.5">
            {type} at <span className="text-foreground/70">{entry}</span>
            {(duration || expiry) && <span className="flex items-center gap-1 text-[10px] bg-white/5 px-1.5 rounded-full"><Timer size={10} /> {duration || expiry}</span>}
          </div>
        </div>
      </div>
      <div className="text-right">
        <div className={`font-bold text-lg ${isCall ? 'text-accent' : 'text-destructive'}`}>
          {pnl}
        </div>
        <div className="text-[9px] text-muted-foreground uppercase tracking-widest font-bold opacity-60">Nexus Payout</div>
      </div>
    </div>
  )
}

function ChecklistItem({ title, completed, link }: any) {
  return (
    <Link href={link}>
      <div className={`flex items-center justify-between p-4 rounded-2xl border transition-all cursor-pointer shadow-sm ${
        completed ? 'bg-accent/10 border-accent/20' : 'bg-white/5 border-white/10 hover:border-accent/50 hover:bg-white/10'
      }`}>
        <div className="flex items-center gap-3">
          {completed ? <CheckCircle2 className="h-5 w-5 text-accent" /> : <div className="h-5 w-5 rounded-full border-2 border-white/10" />}
          <span className={`text-sm font-bold ${completed ? 'text-accent' : 'text-muted-foreground'}`}>{title}</span>
        </div>
        <ChevronRight className="h-4 w-4 text-muted-foreground/40" />
      </div>
    </Link>
  )
}

function StatCard({ title, value, trend, trendType, icon: Icon }: any) {
  return (
    <Card className="border-white/5 shadow-xl bg-card/60 overflow-hidden relative group transition-all hover:bg-card/80">
      <CardHeader className="pb-2">
        <CardDescription className="text-muted-foreground font-bold uppercase text-[10px] tracking-widest flex items-center gap-2">
          <Icon className="h-3 w-3" />
          {title}
        </CardDescription>
        <CardTitle className="text-3xl font-bold tracking-tight text-foreground">{value}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex items-center gap-2">
          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
            trendType === 'up' ? 'bg-accent/10 text-accent' : 
            trendType === 'down' ? 'bg-destructive/10 text-destructive' : 'bg-muted/50 text-muted-foreground'
          }`}>
            {trend}
          </span>
          <span className="text-[10px] text-muted-foreground font-medium uppercase tracking-widest opacity-60">Live Node</span>
        </div>
      </CardContent>
    </Card>
  )
}
