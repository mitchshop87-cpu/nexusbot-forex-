
"use client"

import * as React from "react"
import { 
  History, 
  Search, 
  Download, 
  ArrowUpRight, 
  ArrowDownRight,
  Filter,
  Calendar,
  ChevronRight,
  BarChart2,
  Timer,
  Inbox,
  Clock
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { useFirestore, useUser, useCollection, useMemoFirebase } from "@/firebase"
import { collection, query, orderBy, limit } from "firebase/firestore"

export default function HistoryPage() {
  const db = useFirestore()
  const { user } = useUser()

  const tradesQuery = useMemoFirebase(() => {
    if (!db || !user) return null
    return query(
      collection(db, 'users', user.uid, 'trades'),
      orderBy('time', 'desc'),
      limit(50)
    )
  }, [db, user])

  const { data: trades, loading } = useCollection(tradesQuery)

  return (
    <div className="space-y-8 animate-in fade-in duration-700">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-headline font-bold tracking-tight">Performance History</h1>
          <p className="text-muted-foreground mt-1 text-lg">Detailed audit log (Supports m2 to 24h Durations)</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" className="gap-2 border-white/10 hover:bg-white/5">
            <Download className="h-4 w-4" /> Export CSV
          </Button>
          <Button variant="outline" className="gap-2 border-white/10 hover:bg-white/5">
            <Calendar className="h-4 w-4" /> Date Range
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <SummaryStat title="Total trades" value={trades?.length || "0"} sub="All-time execution" icon={History} />
        <SummaryStat title="Win Rate" value="74.1%" sub="+5.7% (m2 Focus)" icon={BarChart2} accent />
        <SummaryStat title="Total Profit" value="+$4,391.10" sub="Net performance" icon={ArrowUpRight} success />
      </div>

      <Card className="border-white/5 bg-card/40 backdrop-blur-sm overflow-hidden shadow-2xl">
        <CardHeader className="flex flex-row items-center justify-between border-b border-white/5 pb-6">
          <div className="flex items-center gap-4 w-full md:w-auto">
            <div className="relative w-full md:w-80">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input placeholder="Search pair, ID, or type..." className="pl-10 bg-background/50 border-white/10" />
            </div>
            <Button variant="ghost" size="icon" className="hover:bg-white/5">
              <Filter className="h-4 w-4" />
            </Button>
          </div>
          <div className="hidden md:flex gap-2">
            <Badge variant="outline" className="border-white/10 text-[10px] font-bold">ALL</Badge>
            <Badge variant="outline" className="text-muted-foreground border-transparent text-[10px] font-bold">m2 - m5</Badge>
            <Badge variant="outline" className="text-muted-foreground border-transparent text-[10px] font-bold">1h - 24h</Badge>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {loading ? (
            <div className="p-12 text-center text-muted-foreground animate-pulse">Synchronizing trade history...</div>
          ) : !trades || trades.length === 0 ? (
            <div className="p-20 text-center space-y-4">
              <div className="flex justify-center">
                <div className="p-4 bg-white/5 rounded-full">
                  <Inbox className="h-12 w-12 text-muted-foreground opacity-20" />
                </div>
              </div>
              <div className="space-y-1">
                <h3 className="text-xl font-bold">No trades executed yet</h3>
                <p className="text-muted-foreground max-w-xs mx-auto">Activate your strategy and start the robot to begin generating trade history.</p>
              </div>
              <Button variant="outline" className="mt-4" asChild>
                <Link href="/strategy">Go to AI Strategy Studio</Link>
              </Button>
            </div>
          ) : (
            <Table>
              <TableHeader className="bg-muted/30">
                <TableRow className="border-white/5 hover:bg-transparent">
                  <TableHead className="w-[100px] text-[10px] uppercase font-bold text-muted-foreground tracking-widest pl-6">ID</TableHead>
                  <TableHead className="text-[10px] uppercase font-bold text-muted-foreground tracking-widest">Asset Pair</TableHead>
                  <TableHead className="text-[10px] uppercase font-bold text-muted-foreground tracking-widest">Type</TableHead>
                  <TableHead className="text-[10px] uppercase font-bold text-muted-foreground tracking-widest text-right">Stake/Size</TableHead>
                  <TableHead className="text-[10px] uppercase font-bold text-muted-foreground tracking-widest text-right">Entry / Exit</TableHead>
                  <TableHead className="text-[10px] uppercase font-bold text-muted-foreground tracking-widest text-right">Duration</TableHead>
                  <TableHead className="text-[10px] uppercase font-bold text-muted-foreground tracking-widest text-right">P&L</TableHead>
                  <TableHead className="text-[10px] uppercase font-bold text-muted-foreground tracking-widest text-right pr-6">Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {trades.map((trade: any) => {
                  const isCall = trade.type === 'CALL' || trade.type === 'BUY';
                  return (
                    <TableRow key={trade.id} className="border-white/5 hover:bg-white/5 transition-colors group">
                      <TableCell className="font-mono text-xs font-medium pl-6 text-muted-foreground">{trade.id.slice(0, 6)}</TableCell>
                      <TableCell>
                        <div className="font-bold flex items-center gap-2">
                          {trade.pair}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge className={isCall ? 'bg-accent/10 text-accent border-accent/20' : 'bg-destructive/10 text-destructive border-destructive/20'} variant="outline">
                          {trade.type}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right font-medium">{trade.lot || trade.amount}</TableCell>
                      <TableCell className="text-right">
                        <div className="text-sm font-bold">{trade.exit || '-'}</div>
                        <div className="text-[10px] text-muted-foreground">at {trade.entry}</div>
                      </TableCell>
                      <TableCell className="text-right text-xs text-muted-foreground flex justify-end items-center gap-1">
                        <Clock size={12} className="text-primary" />
                        {trade.duration || trade.expiry || 'm5'}
                      </TableCell>
                      <TableCell className={`text-right font-bold ${trade.pnl?.startsWith('+') ? 'text-accent' : trade.pnl?.startsWith('-') ? 'text-destructive' : ''}`}>
                        {trade.pnl || '-'}
                      </TableCell>
                      <TableCell className="text-right pr-6">
                        <Badge variant="secondary" className="text-[10px] font-bold">{trade.status || 'Active'}</Badge>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

function SummaryStat({ title, value, sub, icon: Icon, accent, success }: any) {
  return (
    <Card className="border-white/5 bg-card/60 shadow-lg overflow-hidden relative">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardDescription className="uppercase text-[10px] font-bold tracking-widest">{title}</CardDescription>
          <div className={`p-2 rounded-lg ${accent ? 'bg-accent/10 text-accent' : success ? 'bg-accent/10 text-accent' : 'bg-white/5 text-muted-foreground'}`}>
            <Icon size={16} />
          </div>
        </div>
        <CardTitle className="text-3xl font-bold">{value}</CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-xs text-muted-foreground font-medium">{sub}</p>
      </CardContent>
    </Card>
  )
}
import Link from "next/link"
