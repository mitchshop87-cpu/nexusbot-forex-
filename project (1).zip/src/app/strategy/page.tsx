
"use client"

import * as React from "react"
import { Bot, Sparkles, Save, Play, Square, RefreshCw, Sliders, ShieldAlert, BotIcon as BotI, Target, Info, Timer, Zap, Lock, Crown, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/hooks/use-toast"
import { useFirestore, useUser, useCollection, useMemoFirebase, useDoc } from "@/firebase"
import { collection, addDoc, serverTimestamp, updateDoc, doc } from "firebase/firestore"
import { errorEmitter } from "@/firebase/error-emitter"
import { FirestorePermissionError } from "@/firebase/errors"
import Link from "next/link"

export default function StrategyPage() {
  const [prompt, setPrompt] = React.useState("")
  const [loading, setLoading] = React.useState(false)
  const [isApplying, setIsApplying] = React.useState(false)
  const [strategy, setStrategy] = React.useState<any | null>(null)
  const { toast } = useToast()
  const db = useFirestore()
  const { user } = useUser()

  const subRef = React.useMemo(() => {
    if (!db || !user) return null
    return doc(db, 'users', user.uid, 'config', 'subscription')
  }, [db, user])
  const { data: subData } = useDoc(subRef)
  
  const isPro = subData?.plan === 'pro' || subData?.plan === 'elite' || subData?.status === 'trialing'
  const isTrial = subData?.status === 'trialing'

  const strategiesRef = useMemoFirebase(() => {
    if (!db || !user) return null
    return collection(db, 'users', user.uid, 'strategies')
  }, [db, user])
  
  const { data: strategies } = useCollection(strategiesRef)
  const activeStrategy = strategies?.find(s => s.isActive)

  async function generateStrategy() {
    if (!isPro) {
      toast({
        variant: "destructive",
        title: "Pro Feature Required",
        description: "Upgrade to Cloud Pro or start your 7-Day Free Trial to unlock AI strategy generation."
      })
      return
    }

    if (!prompt) {
      toast({
        variant: "destructive",
        title: "Input required",
        description: "Please describe your preferred trading style first."
      })
      return
    }

    setLoading(true)
    
    setTimeout(() => {
      const isBinary = prompt.toLowerCase().includes('binary') || prompt.toLowerCase().includes('pocket');
      const mockResult = {
        currencyPairs: ["EUR/USD", "GBP/USD", "AUD/USD"],
        riskLevel: "medium",
        type: isBinary ? 'binary' : 'forex',
        duration: isBinary ? "m2" : "1h",
        entryIndicators: ["RSI Oversold", "Bollinger Band Touch", "Volume Spike"],
        exitIndicators: ["Fixed Expiry", "EMA Cross"],
        recommendedAmount: 2.0,
        strategySummary: `Optimized ${isBinary ? 'Binary' : 'Forex'} strategy based on your preference for stability and moderate growth. Using m2 execution logic for rapid signals.`
      }
      setStrategy(mockResult)
      setLoading(false)
      toast({
        title: "Nexus Intelligence Synced",
        description: "Strategy parameters optimized locally for maximum performance."
      })
    }, 1500)
  }

  function handleApplyStrategy() {
    if (!db || !user || !strategy || !strategiesRef) return

    setIsApplying(true)
    
    addDoc(strategiesRef, {
      ...strategy,
      isActive: true,
      createdAt: serverTimestamp()
    })
      .then(() => {
        setIsApplying(false)
        toast({
          title: "Strategy Activated",
          description: "The AI bot is now live with your new strategy."
        })
        setStrategy(null)
      })
      .catch(async () => {
        setIsApplying(false)
        const permissionError = new FirestorePermissionError({
          path: strategiesRef.path,
          operation: 'create',
          requestResourceData: strategy
        })
        errorEmitter.emit('permission-error', permissionError)
      })
  }

  function toggleBotStatus() {
    if (!db || !user || !activeStrategy) return
    
    const strategyDocRef = doc(db, 'users', user.uid, 'strategies', activeStrategy.id)
    updateDoc(strategyDocRef, {
      isActive: !activeStrategy.isActive
    }).catch(async () => {
       const permissionError = new FirestorePermissionError({
          path: strategyDocRef.path,
          operation: 'update',
          requestResourceData: { isActive: !activeStrategy.isActive }
        })
        errorEmitter.emit('permission-error', permissionError)
    })
  }

  return (
    <div className="max-w-6xl mx-auto space-y-8 animate-in slide-in-from-bottom-4 duration-700">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h1 className="text-3xl font-headline font-bold tracking-tight">AI Strategy Studio</h1>
          <p className="text-muted-foreground mt-1 text-lg">Define parameters or use AI to optimize your Binary/Forex bot</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" className="gap-2 border-white/10 hover:bg-white/5">
            <Save className="h-4 w-4" /> Save Draft
          </Button>
          <Button 
            className={`gap-2 shadow-lg ${activeStrategy?.isActive ? 'bg-destructive hover:bg-destructive/90 text-white' : 'bg-primary text-primary-foreground hover:bg-primary/90'}`}
            onClick={toggleBotStatus}
            disabled={!activeStrategy}
          >
            {activeStrategy?.isActive ? (
              <><Square className="h-4 w-4" /> Stop Robot</>
            ) : (
              <><Play className="h-4 w-4" /> Start Robot</>
            )}
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-5 space-y-6">
          <Card className={`border-white/5 bg-card/60 shadow-xl overflow-hidden relative ${!isPro ? 'opacity-90' : ''}`}>
            {!isPro && (
              <div className="absolute inset-0 z-10 bg-background/60 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center">
                <Crown className="h-12 w-12 text-accent mb-4" />
                <h3 className="text-xl font-bold mb-2">Cloud Pro Required</h3>
                <p className="text-sm text-muted-foreground mb-6">Unlock the power of Gemini AI to generate high-accuracy strategies instantly.</p>
                <div className="flex flex-col gap-3 w-full max-w-[240px]">
                  <Button className="bg-primary text-primary-foreground font-bold rounded-xl" asChild>
                    <Link href="/billing">Upgrade Now</Link>
                  </Button>
                  <Button variant="outline" className="border-white/20 hover:bg-white/5 rounded-xl" asChild>
                    <Link href="/billing">Start 7-Day Free Trial</Link>
                  </Button>
                </div>
              </div>
            )}
            <div className="absolute top-0 right-0 p-4">
              <div className="p-2 rounded-full bg-primary/10 text-primary">
                <Sparkles size={20} className="animate-pulse" />
              </div>
            </div>
            <CardHeader>
              <div className="flex items-center gap-2">
                <CardTitle className="text-xl">AI Assistant</CardTitle>
                {isTrial && <Badge className="bg-accent/20 text-accent text-[10px] uppercase font-bold">7-Day Trial Active</Badge>}
              </div>
              <CardDescription>Describe your trading goals. Support durations from <strong>m2 to 24h</strong>.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="preference" className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">Trading Preference</Label>
                <Textarea 
                  id="preference"
                  placeholder="e.g., 'I want a binary option strategy for Pocket Broker with m2 expiry focused on OTC pairs...'"
                  className="min-h-[150px] bg-background/50 border-white/10 focus:border-primary/50 resize-none transition-all"
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  disabled={!isPro}
                />
              </div>
              <Button 
                className="w-full h-12 gap-2 bg-accent text-accent-foreground hover:bg-accent/90" 
                onClick={generateStrategy}
                disabled={loading || !isPro}
              >
                {loading ? (
                  <>
                    <RefreshCw className="h-4 w-4 animate-spin" />
                    Analyzing Market Data...
                  </>
                ) : (
                  <>
                    <Bot className="h-4 w-4" />
                    Generate AI Optimized Strategy
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          <Card className="border-white/5 bg-card/60 shadow-xl">
            <CardHeader>
              <CardTitle className="text-xl flex items-center gap-2">
                <ShieldAlert className="h-5 w-5 text-accent" />
                Risk Management
              </CardTitle>
              <CardDescription>Essential guardrails for automated trading</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-xs font-bold uppercase text-muted-foreground">Max Daily Loss (%)</Label>
                  <Input type="number" defaultValue="2.0" className="bg-background/50 border-white/10" />
                </div>
                <div className="space-y-2">
                  <Label className="text-xs font-bold uppercase text-muted-foreground">Trade Amount (%)</Label>
                  <Input type="number" defaultValue="1.0" className="bg-background/50 border-white/10" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-7 space-y-6">
          {!strategy && !activeStrategy ? (
            <div className="h-full border-2 border-dashed border-white/5 rounded-3xl flex flex-col items-center justify-center p-12 text-center bg-white/5 min-h-[400px]">
              <div className="p-6 rounded-full bg-white/5 mb-6">
                <Sliders className="h-12 w-12 text-muted-foreground opacity-20" />
              </div>
              <h3 className="text-xl font-bold text-muted-foreground mb-2">No Strategy Active</h3>
              <p className="text-muted-foreground max-w-sm">Use the AI Assistant to generate your optimized configuration for Forex or Binary Options.</p>
            </div>
          ) : (
            <div className="space-y-6 animate-in fade-in zoom-in-95 duration-500">
              <Card className={`${strategy ? 'border-accent/30 bg-accent/[0.03]' : 'border-white/5 bg-card/40'} shadow-2xl relative overflow-hidden transition-all`}>
                <CardHeader className="pb-4">
                  <div className="flex justify-between items-start">
                    <Badge className={`${strategy ? 'bg-accent' : 'bg-primary'} text-accent-foreground font-bold tracking-widest uppercase text-[10px]`}>
                      {strategy ? 'AI Generated Proposal' : 'Currently Active Strategy'}
                    </Badge>
                    <Badge variant="outline" className="border-white/20 uppercase text-[10px] font-bold">
                      {strategy?.type || activeStrategy?.type}
                    </Badge>
                  </div>
                  <CardTitle className="text-2xl mt-4 font-headline uppercase tracking-tight">
                    {(strategy?.riskLevel || activeStrategy?.riskLevel)} RISK {(strategy?.type || activeStrategy?.type)}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-8">
                  <div className="space-y-3">
                    <Label className="text-sm font-bold text-muted-foreground uppercase tracking-widest">Strategy Rationale</Label>
                    <div className="p-4 rounded-2xl bg-white/5 border border-white/5 text-sm leading-relaxed text-foreground/90 italic">
                      "{strategy?.strategySummary || activeStrategy?.strategySummary}"
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-8">
                    <div className="space-y-4">
                      <Label className="text-sm font-bold text-muted-foreground uppercase tracking-widest">Asset Selection</Label>
                      <div className="flex flex-wrap gap-2">
                        {(strategy?.currencyPairs || activeStrategy?.currencyPairs || []).map((pair: string) => (
                          <Badge key={pair} variant="outline" className="px-3 py-1 bg-white/10 hover:bg-white/20 border-white/5 text-sm transition-colors">
                            {pair}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <div className="space-y-4">
                      <Label className="text-sm font-bold text-muted-foreground uppercase tracking-widest">Trade Config</Label>
                      <div className="grid grid-cols-1 gap-3">
                         <div className="flex items-center justify-between text-sm">
                            <span className="text-muted-foreground flex items-center gap-1"><Zap size={14} /> Stake</span>
                            <span className="font-bold text-accent">{strategy?.recommendedAmount || activeStrategy?.recommendedAmount}%</span>
                         </div>
                         <div className="flex items-center justify-between text-sm">
                            <span className="text-muted-foreground flex items-center gap-1"><Clock size={14} /> Duration</span>
                            <span className="font-bold text-primary">{strategy?.duration || activeStrategy?.duration || 'm5'}</span>
                         </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {strategy && (
                <div className="flex justify-end gap-3 mt-4">
                  <Button variant="ghost" className="text-muted-foreground" onClick={() => setStrategy(null)}>Discard Proposal</Button>
                  <Button 
                    className="bg-accent text-accent-foreground hover:bg-accent/90 px-8 h-12 rounded-xl shadow-xl shadow-accent/20"
                    onClick={handleApplyStrategy}
                    disabled={isApplying}
                  >
                    {isApplying ? <RefreshCw className="h-4 w-4 animate-spin mr-2" /> : null}
                    Activate & Start Robot
                  </Button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
