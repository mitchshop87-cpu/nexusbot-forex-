'use client';

export const firebaseConfig = {
  apiKey: "AIzaSyB5k_34Q9sogwDxe6RQ9nHSK7ZbwXgwn70",
  authDomain: "studio-8616230657-f0757.firebaseapp.com",
  projectId: "studio-8616230657-f0757",
  storageBucket: "studio-8616230657-f0757.firebasestorage.app",
  messagingSenderId: "799826440247",
  appId: "1:799826440247:web:828cddd7517390791e8fb2",
  measurementId: "G-9802TB0001"
};
