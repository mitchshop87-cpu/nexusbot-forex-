'use client';

import React, { useEffect, useState } from 'react';
import { initializeFirebase } from './index';
import { FirebaseProvider } from './provider';
import { FirebaseErrorListener } from '@/components/FirebaseErrorListener';

export function FirebaseClientProvider({ children }: { children: React.ReactNode }) {
  const [services, setServices] = useState<any>(null);

  useEffect(() => {
    // Only initialize on the client to avoid hydration mismatch
    setServices(initializeFirebase());
  }, []);

  return (
    <FirebaseProvider
      firebaseApp={services?.firebaseApp}
      firestore={services?.firestore}
      auth={services?.auth}
    >
      <FirebaseErrorListener />
      {children}
    </FirebaseProvider>
  );
}