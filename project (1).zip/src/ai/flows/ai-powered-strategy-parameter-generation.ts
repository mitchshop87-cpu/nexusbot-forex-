
/**
 * @fileOverview This file implements a mocked flow for trading parameters.
 * We removed server-side execution to support stable static deployment on Windows.
 */
import { z } from 'genkit';

export const AiPoweredStrategyParameterGenerationInputSchema = z.object({
  userPreference: z.string(),
});
export type AiPoweredStrategyParameterGenerationInput = z.infer<typeof AiPoweredStrategyParameterGenerationInputSchema>;

export const AiPoweredStrategyParameterGenerationOutputSchema = z.object({
  currencyPairs: z.array(z.string()),
  riskLevel: z.enum(['low', 'medium', 'high']),
  type: z.enum(['forex', 'binary']),
  duration: z.string(),
  entryIndicators: z.array(z.string()),
  exitIndicators: z.array(z.string()),
  stopLossPercentage: z.number().optional(),
  takeProfitPercentage: z.number().optional(),
  recommendedAmount: z.number(),
  strategySummary: z.string(),
});
export type AiPoweredStrategyParameterGenerationOutput = z.infer<typeof AiPoweredStrategyParameterGenerationOutputSchema>;

export async function aiPoweredStrategyParameterGeneration(
  input: AiPoweredStrategyParameterGenerationInput
): Promise<AiPoweredStrategyParameterGenerationOutput> {
  const isBinary = input.userPreference.toLowerCase().includes('binary') || input.userPreference.toLowerCase().includes('pocket');
  
  return {
    currencyPairs: ["EUR/USD", "GBP/USD", "AUD/USD"],
    riskLevel: "medium",
    type: isBinary ? 'binary' : 'forex',
    duration: isBinary ? "m2" : "1h",
    entryIndicators: ["RSI Oversold", "Bollinger Band Touch"],
    exitIndicators: ["EMA Cross"],
    recommendedAmount: 2.0,
    strategySummary: `Autonomous ${isBinary ? 'Binary' : 'Forex'} profile optimized for the current market cycle.`
  };
}
