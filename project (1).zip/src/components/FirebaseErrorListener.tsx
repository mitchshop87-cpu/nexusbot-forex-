'use client';

import { useEffect } from 'react';
import { errorEmitter } from '@/firebase/error-emitter';
import { FirestorePermissionError } from '@/firebase/errors';
import { useToast } from '@/hooks/use-toast';

export function FirebaseErrorListener() {
  const { toast } = useToast();

  useEffect(() => {
    const handleError = (error: FirestorePermissionError) => {
      // In development, this will also trigger the Next.js error overlay 
      // because it's an unhandled emission if we throw it here.
      // But we use toast for user feedback in production-like UI.
      toast({
        variant: 'destructive',
        title: 'Security Permission Denied',
        description: `Check console for details on: ${error.context.path}`,
      });
      console.error(error.message, error.context);
    };

    errorEmitter.on('permission-error', handleError);
    return () => {
      errorEmitter.off('permission-error', handleError);
    };
  }, [toast]);

  return null;
}
