"use client"

import * as React from "react"
import {
  LayoutDashboard,
  Zap,
  History,
  Settings,
  Bell,
  Activity,
  BarChart3,
  Bot,
  Cloud,
  CreditCard,
  Crown,
  ShieldAlert
} from "lucide-react"
import { usePathname } from "next/navigation"
import Link from "next/link"
import Image from "next/image"

import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarSeparator,
} from "@/components/ui/sidebar"
import { useUser, useFirestore, useDoc } from "@/firebase"
import { doc } from "firebase/firestore"

const navigation = [
  { name: "Dashboard", href: "/", icon: LayoutDashboard },
  { name: "Strategy AI", href: "/strategy", icon: Bot },
  { name: "Trade History", href: "/history", icon: History },
  { name: "Notifications", href: "/notifications", icon: Bell },
  { name: "Billing & Plans", href: "/billing", icon: CreditCard },
  { name: "Account Settings", href: "/settings", icon: Settings },
]

export function AppSidebar() {
  const pathname = usePathname()
  const { user } = useUser()
  const db = useFirestore()

  const subRef = React.useMemo(() => {
    if (!db || !user) return null
    return doc(db, 'users', user.uid, 'config', 'subscription')
  }, [db, user])

  const { data: subData } = useDoc(subRef)
  const currentPlan = subData?.plan || "free"

  const isAdmin = true; 

  return (
    <Sidebar variant="inset" collapsible="icon">
      <SidebarHeader className="p-4">
        <div className="flex items-center gap-3">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-lg overflow-hidden relative border border-white/10">
            <Image 
              src="https://picsum.photos/seed/nexus-pro-v1/512/512" 
              alt="Nexus Pro Logo" 
              fill
              className="object-cover"
              data-ai-hint="nexus pro logo"
            />
          </div>
          <div className="flex flex-col group-data-[collapsible=icon]:hidden">
            <div className="flex items-center gap-2">
              <span className="font-headline font-black text-xl leading-none tracking-tighter">NEXUS PRO</span>
              {currentPlan !== 'free' && (
                <Crown className="h-3 w-3 text-accent fill-accent" />
              )}
            </div>
            <span className="text-[10px] text-accent mt-1 uppercase font-bold tracking-[0.2em]">v1.0.0 ULTIMATE</span>
          </div>
        </div>
      </SidebarHeader>
      <SidebarContent>
        <SidebarMenu className="px-2 mt-4">
          {navigation.map((item) => (
            <SidebarMenuItem key={item.name}>
              <SidebarMenuButton
                asChild
                isActive={pathname === item.href}
                tooltip={item.name}
                className="hover:bg-primary/10 active:bg-primary/20 transition-all"
              >
                <Link href={item.href}>
                  <item.icon className={pathname === item.href ? "text-primary" : "text-muted-foreground"} />
                  <span className="font-medium">{item.name}</span>
                </Link>
              </SidebarMenuButton>
            </SidebarMenuItem>
          ))}
          
          {isAdmin && (
            <>
              <SidebarSeparator className="my-2 opacity-20" />
              <SidebarMenuItem>
                <SidebarMenuButton
                  asChild
                  isActive={pathname === '/admin'}
                  tooltip="Admin Panel"
                  className="hover:bg-accent/10 active:bg-accent/20 transition-all group"
                >
                  <Link href="/admin">
                    <ShieldAlert className={pathname === '/admin' ? "text-accent" : "text-muted-foreground group-hover:text-accent"} />
                    <span className="font-bold text-accent">Admin Overview</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </>
          )}
        </SidebarMenu>
        
        <SidebarSeparator className="my-6 mx-4" />
        
        <div className="px-6 group-data-[collapsible=icon]:hidden">
          <div className="bg-secondary/40 rounded-xl p-4 border border-border/50">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">Nexus Brain</span>
              <div className="h-2 w-2 rounded-full bg-accent animate-status-active" />
            </div>
            <div className="flex items-center gap-2">
              <Cloud size={14} className="text-accent" />
              <span className="text-sm font-bold text-accent">24/7 Engine Active</span>
            </div>
            <p className="text-[9px] text-muted-foreground mt-2 uppercase font-medium">Plan: {currentPlan.toUpperCase()}</p>
          </div>
        </div>
      </SidebarContent>
      <SidebarFooter className="p-4 border-t border-border/50">
        <div className="flex items-center gap-3 group-data-[collapsible=icon]:hidden">
          <div className="h-10 w-10 rounded-full bg-secondary border border-border overflow-hidden shadow-inner">
             <Image 
              src="https://picsum.photos/seed/user-pro/100/100" 
              alt="Avatar" 
              width={40}
              height={40}
              className="w-full h-full object-cover" 
              data-ai-hint="trader avatar"
            />
          </div>
          <div className="flex flex-col overflow-hidden">
            <span className="text-sm font-bold truncate text-foreground">{user?.displayName || "Nexus Master"}</span>
            <span className="text-[10px] text-muted-foreground truncate uppercase font-bold tracking-widest opacity-60">v1.0.0 • {currentPlan === 'free' ? 'Starter' : currentPlan.toUpperCase()}</span>
          </div>
        </div>
      </SidebarFooter>
    </Sidebar>
  )
}
