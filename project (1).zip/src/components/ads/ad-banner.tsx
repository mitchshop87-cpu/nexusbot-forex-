'use client';

import * as React from 'react';

/**
 * AdBanner component for Google AdSense with a ResizeObserver fix 
 * to prevent "No slot size for availableWidth=0" errors.
 */
export function AdBanner({ className }: { className?: string }) {
  const adRef = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    let initialized = false;

    const initAd = () => {
      if (initialized) return;
      try {
        if (typeof window !== 'undefined' && adRef.current && adRef.current.offsetWidth > 0) {
          // @ts-ignore
          (window.adsbygoogle = window.adsbygoogle || []).push({});
          initialized = true;
        }
      } catch (err) {
        if (process.env.NODE_ENV === 'development') {
          console.debug('AdSense initialization skipped:', err);
        }
      }
    };

    const observer = new ResizeObserver((entries) => {
      for (const entry of entries) {
        if (entry.contentRect.width > 250) {
          initAd();
          observer.disconnect();
        }
      }
    });

    if (adRef.current) {
      observer.observe(adRef.current);
    }

    return () => {
      observer.disconnect();
    };
  }, []);

  return (
    <div 
      ref={adRef}
      className={`w-full overflow-hidden flex justify-center py-4 bg-card/20 rounded-2xl border border-white/5 my-6 min-h-[90px] ${className}`}
    >
      <ins
        className="adsbygoogle"
        style={{ display: 'block', width: '100%', minWidth: '250px', height: '90px' }}
        data-ad-client="ca-pub-6830176057072253"
        data-ad-slot="1586326287"
        data-ad-format="horizontal"
        data-full-width-responsive="true"
      />
    </div>
  );
}